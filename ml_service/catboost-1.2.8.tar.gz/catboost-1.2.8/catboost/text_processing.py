from . import _catboost

Tokenizer = _catboost.Tokenizer
Dictionary = _catboost.Dictionary
