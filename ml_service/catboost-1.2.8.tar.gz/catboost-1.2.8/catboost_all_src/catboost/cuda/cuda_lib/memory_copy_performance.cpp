#include "memory_copy_performance.h"

using namespace NCudaLib;
