#pragma once

namespace NCatboostCuda {
    template <class TModel>
    class TAddModelDocParallel;
}
