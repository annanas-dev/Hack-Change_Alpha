#pragma once

enum class EOperatorType {
    Sum,
    Min,
    Max,
    L1Sum,
};
