module.exports = require('./CatboostIpython.js');
module.exports['version'] = require('../package.json').version;